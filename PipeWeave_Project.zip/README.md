# PipeWeave 🚀
### Enterprise-Grade Full-Stack Data Pipeline Orchestration & Stream Processing Engine

[![CI/CD Pipeline](https://github.com/Chandravamsi09/PipeWeave/actions/workflows/ci.yml/badge.svg)](https://github.com/Chandravamsi09/PipeWeave/actions)
[![License: Apache 2.0](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](LICENSE)
[![Python Version](https://img.shields.io/badge/python-3.11%2B-blue.svg)](https://www.python.org/downloads/)
[![React Version](https://img.shields.io/badge/react-19.0-61dafb.svg)](https://reactjs.org/)
[![TypeScript](https://img.shields.io/badge/typescript-5.4-blue.svg)](https://www.typescriptlang.org/)
[![DuckDB](https://img.shields.io/badge/DuckDB-Vectorized-yellow.svg)](https://duckdb.org/)
[![Polars](https://img.shields.io/badge/Polars-LazyFrames-orange.svg)](https://pola.rs/)

PipeWeave is a next-generation distributed data pipeline orchestration, stream ingestion, and transformation platform. It empowers data engineers, analytics engineers, and platform teams to build, test, monitor, and govern end-to-end data workflows visually and programmatically.

---

## 🌟 Key Features

### 1. ⚙️ High-Performance DAG Orchestration Engine
- **Kahn's Topological Sorting & Cycle Detection**: Ultra-fast dependency resolution and cycle prevention using Tarjan's algorithm.
- **Dynamic Task State Machine**: Robust lifecycle handling (`PENDING`, `SCHEDULED`, `RUNNING`, `SUCCESS`, `FAILED`, `RETRYING`, `SKIPPED`, `CANCELLED`).
- **Resilient Worker Pool**: Async worker dispatch with concurrency limits, thread/process pools, exponential backoff retries with jitter, and circuit breakers.
- **XCom Parameter Passing**: Type-safe inter-node parameter and data passing across task runs.

### 2. 🔌 Extensible Multi-Source Ingestion & Sink Connectors
- **Streaming Ingestion**: Apache Kafka, AWS Kinesis, Webhook push receivers, Server-Sent Events.
- **Databases & Warehouses**: PostgreSQL, MySQL, ClickHouse, Snowflake, Google BigQuery, Amazon Redshift.
- **Data Lake & Object Stores**: Amazon S3 (Parquet, Delta, CSV, JSON), Google Cloud Storage, Azure Blob Storage.
- **Search & Document Stores**: Elasticsearch, OpenSearch, MongoDB.
- **API & File Connectors**: REST API poller with cursor/page pagination, OAuth2/Bearer auth, and local file storage.

### 3. ⚡ Vectorized Transformation & Stream Windowing
- **In-Memory DuckDB Engine**: Zero-copy vectorized SQL execution across batch tables and streaming data frames.
- **Polars LazyFrame Pipelines**: Lightning-fast columnar transformations, predicate pushdowns, and parallel projections.
- **Stream Windowing Operators**: Tumbling, Sliding, Session (inactivity gap), and Hopping windows with event-time watermarking and late-data side-outputs.
- **Sandboxed Python UDFs**: Isolated user-defined function execution with runtime resource quotas.

### 4. 🛡️ Automated Data Quality & Anomaly Detection
- **Great Expectations-Inspired Assertions**: Null checks, unique constraints, numerical ranges, regex patterns, freshness tolerances, entropy distributions, and custom SQL assertions.
- **Automated Column Profiling**: Complete statistical distributions, distinct counts, quantiles (p25, p50, p75, p99), and histogram generation.
- **Statistical Anomaly Detection**: Real-time sliding window Z-score and IQR anomaly detection on incoming data streams.
- **Configurable Quality Gates**: Hard failure, non-blocking warning, or automatic routing to Quarantine/Dead-Letter Queues (DLQ).

### 5. 📜 Schema Registry & Governance
- **Multi-Format Schema Evolution**: JSON Schema, Apache Avro, and Protocol Buffers support.
- **Compatibility Modes**: `BACKWARD`, `FORWARD`, `FULL`, `BACKWARD_TRANSITIVE`, `FORWARD_TRANSITIVE`, `FULL_TRANSITIVE`, `NONE`.
- **Column-Level Lineage Graph**: Automated AST parsing from SQL transforms and pipeline nodes with upstream root-cause analysis and downstream blast-radius tracking.

### 6. 🎨 Visual Pipeline Studio (React 19 + TypeScript)
- **Interactive Visual DAG Canvas**: Custom drag-and-drop nodes, animated streaming edges, auto-layout algorithms, and minimap.
- **Monaco SQL & Python IDE**: In-browser code editor with syntax highlighting, schema autocompletion, and live query execution.
- **Real-Time Telemetry Dashboard**: Throughput graphs (records/sec), latency percentiles (p50/p95/p99), worker saturation gauges, and live execution log streaming via WebSockets.
- **Side-by-Side Schema Diff Viewer**: Visual version comparison and compatibility indicator.

---

## 🏛️ System Architecture

```
                           +-----------------------------------------------+
                           |          PipeWeave Web Studio (React)        |
                           |  - Visual DAG Builder (React Flow)            |
                           |  - Real-Time Stream Telemetry                 |
                           |  - Monaco SQL/Python Transformation IDE       |
                           |  - Column Lineage & Schema Diff Viewer        |
                           +-----------------------+-----------------------+
                                                   |
                                                   | HTTP REST / WebSockets
                                                   v
                           +-----------------------------------------------+
                           |          PipeWeave Orchestration API          |
                           |  - FastAPI Async REST Server                  |
                           |  - DAG Scheduler & Dependency Resolver        |
                           |  - Event Bus & State Machine                  |
                           |  - Telemetry Aggregator & Prometheus Exporter |
                           +-----------------------+-----------------------+
                                                   |
                     +-----------------------------+-----------------------------+
                     |                             |                             |
                     v                             v                             v
       +---------------------------+ +---------------------------+ +---------------------------+
       |   DAG Execution Engine    | |  Connectors & I/O Engine  | |  Transform & Stream Engine|
       |  - Topological Scheduler  | |  - Kafka Consumer/Producer| |  - DuckDB Vectorized SQL  |
       |  - Async Worker Pool      | |  - Postgres/MySQL/ClickH. | |  - Polars LazyFrames      |
       |  - Retry / Circuit Breaker| |  - S3 / Parquet Storage   | |  - Tumbling/Sliding Window|
       |  - Inter-Task XCom Bus    | |  - REST API Poller / Hook | |  - Sandboxed Python UDFs  |
       +---------------------------+ +---------------------------+ +---------------------------+
                     |                             |                             |
                     +-----------------------------+-----------------------------+
                                                   |
                                                   v
                           +-----------------------------------------------+
                           |     Data Quality, Lineage & Governance        |
                           |  - Assertion Rule Engine (Null, Range, Regex) |
                           |  - Statistical Anomaly Detector (Z-Score/IQR) |
                           |  - Schema Registry (Avro/JSONSchema/Proto)    |
                           |  - Column-Level Lineage Graph Parser          |
                           +-----------------------------------------------+
```

---

## 📁 Repository Structure

```
PipeWeave/
├── .github/
│   └── workflows/
│       ├── ci.yml                    # Automated lint, typecheck, and test runner
│       ├── lint-and-typecheck.yml    # Python Flake8/Black/Mypy & TypeScript ESLint
│       ├── docker-build.yml          # Container image build & security scanning
│       └── pr-automation.yml         # Pull request labels, changelog & checks
├── backend/
│   ├── src/pipeweave/
│   │   ├── api/                      # FastAPI Routers & Endpoints
│   │   │   ├── routers/
│   │   │   │   ├── pipelines.py      # Pipeline definition CRUD & DAG validation
│   │   │   │   ├── runs.py           # Pipeline run execution & live task logs
│   │   │   │   ├── connectors.py     # Connection testing & schema discovery
│   │   │   │   ├── transforms.py     # SQL/Python interactive playground
│   │   │   │   ├── quality.py        # Assertion rules & profiling metrics
│   │   │   │   ├── schema.py         # Schema Registry & compatibility checks
│   │   │   │   ├── lineage.py        # Column-level lineage graphs
│   │   │   │   └── telemetry.py      # Prometheus metrics & live status
│   │   │   └── main.py               # Application factory & WebSocket hub
│   │   ├── core/                     # Core configs, events, exceptions, types
│   │   ├── engine/                   # DAG topological scheduler, workers, retries
│   │   ├── connectors/               # 12+ Source & Sink connector implementations
│   │   ├── transforms/               # DuckDB, Polars, and stream windowing
│   │   ├── quality/                  # Data quality rules, profiler, anomaly detector
│   │   ├── schema_registry/          # Schema versioning & compatibility checks
│   │   ├── lineage/                  # Column lineage parser & impact analyzer
│   │   ├── telemetry/                # Metrics collector & WebSocket broadcaster
│   │   ├── db/                       # SQLAlchemy models & repository layer
│   │   └── utils/                    # Data generators, serializers, validators
│   └── pyproject.toml                # Backend dependencies & tool configurations
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── dag/                  # Visual DAG Builder (Canvas, Custom Nodes)
│   │   │   ├── transforms/           # Monaco SQL/Python IDE & Data Grid
│   │   │   ├── monitoring/           # Real-Time Telemetry & Throughput Charts
│   │   │   ├── schema/               # Schema Registry & Version Diff Viewer
│   │   │   ├── lineage/              # Interactive Column Lineage Visualizer
│   │   │   ├── connectors/           # Connector Manager & Vault Modals
│   │   │   ├── runs/                 # Run History & Task Log Streamer
│   │   │   └── common/               # UI components (Buttons, Modals, Badges)
│   │   ├── store/                    # Zustand state management slices
│   │   ├── services/                 # API client SDK & WebSocket listeners
│   │   ├── hooks/                    # Custom React hooks
│   │   ├── types/                    # TypeScript interfaces & domain types
│   │   ├── App.tsx                   # Main layout & route navigation
│   │   └── main.tsx                  # React DOM entrypoint
│   ├── package.json                  # Frontend dependencies (React 19, Tailwind)
│   ├── tsconfig.json                 # TypeScript compiler options
│   ├── vite.config.ts                # Vite bundler configuration
│   └── tailwind.config.js            # Tailwind CSS design system
├── tests/
│   ├── unit/                         # Unit tests (DAG, Retries, Transforms, Rules)
│   ├── integration/                  # Integration tests (Connectors, Schema, Storage)
│   ├── e2e/                          # End-to-end full pipeline execution tests
│   └── frontend/                     # Frontend component & state tests
├── docker/                           # Dockerfiles & multi-container Docker Compose
├── k8s/                              # Kubernetes Helm charts & deployment manifests
└── docs/                             # Architecture blueprints & API guides
```

---

## 🚀 Quick Start

### 1. Prerequisites
- Python 3.11+
- Node.js 20+ and npm
- Docker & Docker Compose (optional for containerized deployment)

### 2. Backend Setup
```bash
cd backend
python -m venv venv
# On Windows:
venv\Scripts\activate
# On Linux/macOS:
source venv/bin/activate

pip install -e .
python -m pipeweave.api.main
```
The REST API and interactive Swagger docs will be live at `http://localhost:8000/docs`.

### 3. Frontend Setup
```bash
cd frontend
npm install
npm run dev
```
The Web Studio will be available at `http://localhost:5173`.

---

## 🧪 Running the Test Suite

```bash
# Run backend unit, integration, and E2E tests
pytest -v tests/

# Run frontend tests
npm run test:ui
```

---

## 📄 License
PipeWeave is released under the [Apache 2.0 License](LICENSE).
